package com.example.simple_flutter_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
